<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title> Authorization </title>

<style type="text/css">
     body{
        background: linear-gradient(to left, #586e91, #58917f);
     }


</style>


    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>



      $query = "INSERT INTO accounts(username. email. password. ) VALUES ('$username'. '$email'. '$password' )";
      $result = mysqli_query($connection, $query);

      if ($result) {
        $smsg = "Login successfull";       
      }else{
         $fsmsg = "Error";
      }
}
 ?>


<div class="container">

    <form class="sign-in" method="POST"> 
   <h2> Log-in </h2>

    <input type="text" name="username" class="form-control" placeholder="Username" required="">
    
      <input type="password" name="password" class="form-control" placeholder="Password" required="">

     <button class="btn btn-lg btn-primary btn-block" type="submit" > Login </button>
     <a href="mediahost.php" class="btn btn-lg btn-primary btn-block"> Registration </a>
     </form>
   </div>

<?php
session_start();
require('connect.php')

   if(isset($_POST['username']) and isset($_POST['password'])) {
    $username = $_POST['username'];
      $password = $_POST['password'];

 $query = "SELECT * FROM accounts WHERE username = '$username' and password ='$password'";
 $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
 $count = mysqli_num_rows($result);

 if ($count == 1){
  $_SESSION['username'] = $username;
 }else {
  $fmsg = "Error";
 }
}

if (isset($_SESSION['username'])){
  $username = $_SESSION['username'];
  echo "Hello" . $username . "";
  echo "You Entered!"
  echo "<a href='logout.php' class='btn btn-lg btn-primary'>Logout </a>";
}


?>


</body>
</html>